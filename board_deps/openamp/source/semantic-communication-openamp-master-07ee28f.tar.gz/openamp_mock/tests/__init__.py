"""Tests for OpenAMP mock."""
