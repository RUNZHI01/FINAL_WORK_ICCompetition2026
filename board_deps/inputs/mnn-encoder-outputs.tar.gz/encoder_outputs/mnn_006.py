import os
import glob
import logging
import argparse
from tqdm.auto import tqdm
import torch
import torchvision
import numpy as np
import MNN
from concurrent.futures import ThreadPoolExecutor, as_completed

# 设置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 定义预加载函数
def preload_data(pt_files):
    data_list = []
    for pt_file in pt_files:
        try:
            data = torch.load(pt_file, map_location="cpu", weights_only=True)
            data_list.append((pt_file, data))
            logger.info(f"预加载文件: {pt_file}")
        except Exception as e:
            logger.error(f"预加载文件失败 {pt_file}: {str(e)}")
    return data_list

# 定义 AWGNChannel 函数
def AWGNChannel(y, snr):
    with torch.no_grad():
        pwr = torch.mean(y ** 2, (-3, -2, -1), keepdim=True) * 2
        noise_pwr = pwr * 10 ** (-snr / 10)
    noise = torch.sqrt(noise_pwr / 2) * torch.randn_like(y)
    y_noisy = y + noise
    return y_noisy

# 解析命令行参数
parser = argparse.ArgumentParser(description="使用 MNN 优化模型重构图像")
parser.add_argument("--input_dir", type=str, required=True, help="包含 .pt 文件的目录")
parser.add_argument("--output_dir", type=str, required=True, help="保存重构 .png 文件的目录")
parser.add_argument("--snr", type=float, required=True, help="信噪比")
parser.add_argument("--model_path", type=str, required=True, help="MNN 模型文件路径")
args = parser.parse_args()

# 加载 MNN 模型，创建两个Interpreter和各自的Session
try:
    interpreter1 = MNN.Interpreter(args.model_path)
    session1 = interpreter1.createSession()
    interpreter2 = MNN.Interpreter(args.model_path)
    session2 = interpreter2.createSession()
    logger.info("MNN 模型加载成功，创建了两个Interpreter和Session")
except Exception as e:
    logger.error(f"MNN 模型加载失败: {str(e)}")
    raise

# 获取 .pt 文件列表
pt_files = glob.glob(os.path.join(args.input_dir, "*.pt"))
pt_files = sorted(pt_files)
if not pt_files:
    logger.error(f"输入目录中未找到 .pt 文件: {args.input_dir}")
    raise ValueError("输入目录为空")

# 预加载所有 .pt 文件
data_list = preload_data(pt_files)

# 创建重构图像保存目录
reconstructions_dir = os.path.join(args.output_dir, "reconstructions")
os.makedirs(reconstructions_dir, exist_ok=True)

# 定义处理函数
def process_data(data_item, session, interpreter):
    pt_file, data = data_item
    try:
        # 提取文件名
        base_name = os.path.basename(pt_file).split('_latent')[0]
        required_keys = {'quant', 'scale', 'zero_point'}
        if not all(key in data for key in required_keys):
            raise KeyError(f"文件 {pt_file} 缺少必要键")
        q_tensor = data['quant']
        scale = data['scale']
        zero_point = data['zero_point']
        # 去量化
        y_dequant = (q_tensor.float() - zero_point) * scale
        # 添加噪声
        y_noisy = AWGNChannel(y_dequant.unsqueeze(0), args.snr)
        
        # 获取输入数据的高度 H
        N, C, H, W = y_noisy.shape
        logger.info(f"输入数据形状: {N}, {C}, {H}, {W}")
        
        # 获取 MNN 输入张量
        input_tensor = interpreter.getSessionInput(session)
        
        # 调整输入张量形状为 (N, C, H, W)
        new_shape = (N, C, H, W)
        interpreter.resizeTensor(input_tensor, new_shape)
        interpreter.resizeSession(session)
        logger.info(f"调整输入张量形状为: {new_shape}")
        
        # 准备 MNN 输入数据
        y_noisy_np = y_noisy.numpy().astype(np.float32)
        tmp_tensor = MNN.Tensor(new_shape, MNN.Halide_Type_Float, y_noisy_np, MNN.Tensor_DimensionType_Caffe)
        input_tensor.copyFrom(tmp_tensor)
        
        # 运行 MNN 模型
        interpreter.runSession(session)
        
        # 获取 MNN 输出 Tensor
        output_tensor = interpreter.getSessionOutput(session)
        output_data = output_tensor.getData()
        
        # 将数据转换为 numpy array 并 reshape
        output_shape = output_tensor.getShape()
        output_array = np.array(output_data, dtype=np.float32).reshape(output_shape)
        recon = torch.from_numpy(output_array)
        
        # 检查值范围
        logger.info(f"recon min: {recon.min().item()}, max: {recon.max().item()}")
        
        # 保存重构图像
        save_path = os.path.join(reconstructions_dir, f"{base_name}_recon.png")
        torchvision.utils.save_image(recon.clamp(0, 1), save_path, format='PNG')
        logger.info(f"重构图像保存至: {save_path}")
        return True
    except Exception as e:
        logger.error(f"处理文件失败 {pt_file}: {str(e)}")
        return False

# 使用 ThreadPoolExecutor 进行并行处理
processed_count = 0
total_files = len(data_list)
with tqdm(total=total_files, desc="重构中") as pbar:
    with ThreadPoolExecutor(max_workers=2) as executor:
        futures = []
        for i, data_item in enumerate(data_list):
            if i % 2 == 0:
                futures.append(executor.submit(process_data, data_item, session1, interpreter1))
            else:
                futures.append(executor.submit(process_data, data_item, session2, interpreter2))
        
        for future in as_completed(futures):
            if future.result():
                processed_count += 1
            pbar.update(1)

logger.info(f"处理完成: {processed_count}/{total_files} 文件成功")